Download and Requirement link - http://portfolio.matrixbuildhome.com/ARsketching.html
 
Steps:-

1) Copy all the dll files in C:/Windows/System32 or C:/Windows/System64
2) Run arsktech.exe 
3) If any dll file is still missing download and copy as in step 1

Note : you need a working webcamera to run this project 